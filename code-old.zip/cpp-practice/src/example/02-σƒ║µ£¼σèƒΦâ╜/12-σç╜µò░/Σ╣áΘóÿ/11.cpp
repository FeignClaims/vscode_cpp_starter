/**
 * TODO:
 *\>Write a program to help decipher messages encrypted with the method
 *\>described in §X.13[9] without knowing the key. Hint: See David Kahn: The
 *\>Codebreakers, Macmillan, 1967, New York, pp. 207-213.
 */