/**
 * TODO:
 *\>Write a Checked_ptr<T> that uses exceptions to signal run-time errors for a
 *\>pointer supposed to point to an element of an array (or
 *\>one-beyond-the-end-of the array).
 */