#include <compare>
#include <iostream>

int x;

int main() {
  int x{};
  std::cout << std::boolalpha << true << '\n';
}