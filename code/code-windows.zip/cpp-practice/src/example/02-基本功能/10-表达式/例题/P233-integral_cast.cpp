auto main() -> int {
  unsigned char uc =
      1023;  // 二进制 1111111111：uc 的值变为二进制 11111111，即 255
  signed char sc = 1023;  // 依赖于实现
}