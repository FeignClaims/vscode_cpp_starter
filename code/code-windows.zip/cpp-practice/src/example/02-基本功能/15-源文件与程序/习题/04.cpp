/**
 * TODO:Modify the program from the previous exercise to print the number of
 *\>comment lines, the number of non-comment lines, and the number of
 *\>non-comment, whitespace-separated words for each file #included.
 */