#include "dc.hpp"

auto parser::prim(bool get) -> double { /*...*/
}
auto parser::term(bool get) -> double { /*...*/
}
auto parser::expr(bool get) -> double { /*...*/
}