#include "error.hpp"

int error::number_of_errors;
auto error::error(const std::string& s) -> double { /*...*/
}