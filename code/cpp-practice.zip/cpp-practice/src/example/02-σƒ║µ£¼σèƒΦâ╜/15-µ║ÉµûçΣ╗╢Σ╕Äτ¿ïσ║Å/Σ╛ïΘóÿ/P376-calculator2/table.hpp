#include <map>
#include <string>

namespace table {
extern std::map<std::string, double> table;
}  // namespace table