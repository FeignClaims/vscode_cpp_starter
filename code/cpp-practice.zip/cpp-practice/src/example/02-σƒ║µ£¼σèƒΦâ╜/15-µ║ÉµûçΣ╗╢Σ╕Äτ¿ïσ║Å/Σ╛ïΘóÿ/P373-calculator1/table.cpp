#include "dc.hpp"

std::map<std::string, double> table::table;