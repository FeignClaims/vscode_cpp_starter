#include "dc.hpp"
// 任何其他 #includes 或声明

int error::no_of_errors;
auto error::error(const std::string& s) -> double { /*...*/
}