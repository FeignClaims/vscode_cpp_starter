#include "table.hpp"

std::map<std::string, double> table::table;