#include "dc.hpp"

#include <iostream>  // 冗余：dc.h 中已经有了
#include <sstream>

void driver::calculate() { /*...*/
}

auto main(int argc, char* argv[]) -> int { /*...*/
}