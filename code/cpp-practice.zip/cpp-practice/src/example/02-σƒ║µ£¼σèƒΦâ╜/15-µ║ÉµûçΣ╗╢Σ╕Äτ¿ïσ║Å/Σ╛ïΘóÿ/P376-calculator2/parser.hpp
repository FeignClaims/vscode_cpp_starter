// 用户接口
namespace parser {
auto expr(bool get) -> double;
}  // namespace parser