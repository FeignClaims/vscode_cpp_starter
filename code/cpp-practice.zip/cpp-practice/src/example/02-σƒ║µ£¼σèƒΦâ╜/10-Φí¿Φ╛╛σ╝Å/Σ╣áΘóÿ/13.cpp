/** TODO
 *\>Allow a user to define functions in the calculator. Hint: Define a function
 *\>as a sequence of operations just as a user would have typed them. Such a
 *\>sequence can be stored either as a character string or as a list of tokens.
 *\>Then read and execute those operations when the function is called. If you
 *\>want a user-defined function to take arguments, you will have to inv ent a
 *\>notation for that.
 */