/** TODO
 *\>Type in the calculator example and get it to work. Do not "save time" by
 *\>using an already entered text. You’ll learn most from finding and correcting
 *\>"little silly errors."
 */