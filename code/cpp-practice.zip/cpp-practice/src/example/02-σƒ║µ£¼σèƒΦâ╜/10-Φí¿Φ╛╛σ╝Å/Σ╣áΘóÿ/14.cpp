/** TODO
 *\>Convert the desk calculator to use a symbol structure instead of using the
 *\>static variables number_value and string_value
 */