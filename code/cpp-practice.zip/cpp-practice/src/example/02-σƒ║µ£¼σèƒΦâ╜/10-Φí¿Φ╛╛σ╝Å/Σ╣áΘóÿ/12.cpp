/** TODO
 *\>Modify the calculator to report line numbers for errors.
 */