/**
 * TODO
 *\>Write a table of values for the bitwise logical operations (§11.1.1)
 *\>for all possible combinations of 0 and 1 operands.
 */