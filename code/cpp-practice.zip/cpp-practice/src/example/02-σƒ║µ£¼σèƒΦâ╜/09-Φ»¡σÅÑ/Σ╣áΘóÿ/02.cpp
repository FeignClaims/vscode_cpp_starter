void f(int a, int b) {
  if (a = 3) {
    // ...
    ;
  }
  if (a & 077 == 0) {
    // ...
    ;
  }
a:
  = b + 1;
}