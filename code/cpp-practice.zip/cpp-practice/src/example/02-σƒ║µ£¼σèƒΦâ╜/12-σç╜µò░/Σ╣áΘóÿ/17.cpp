/**
 * TODO:
 *\>Write an error function that takes a printf-style format string containing
 *\>%s, %c, and %d directives and an arbitrary number of arguments. Don’t use
 *\>printf(). Look at §43.3 if you don’t know the meaning of %s, %c, and %d. Use
 *\><cstdarg>.
 */