/**
 * TODO:
 *\>Without using copy and paste, implement and test TEA (the Tiny Encryption
 *\>Algorithm). D.J. Wheeler and R.M. Needham: TEA, a tiny encryption algorithm.
 *\>Lecture Notes in Computer Science 1008: 363366.
 *\>http://143.53.36.235:8080/tea.htm
 */