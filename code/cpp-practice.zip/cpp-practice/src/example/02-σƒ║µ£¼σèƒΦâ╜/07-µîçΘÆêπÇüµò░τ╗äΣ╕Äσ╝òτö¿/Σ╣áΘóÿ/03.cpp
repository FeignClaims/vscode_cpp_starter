using a = unsigned char;
using b = const unsigned char;
using c = int*;
using d = char**;
using e = char (*)[];
using f = int* [7];
using g = int* (*)[7];
using h = int* [8][7];