namespace American_Telephone_and_Telegraph {  // 短名字，（最终）可能冲突
// ...
}  // namespace American_Telephone_and_Telegraph

// STAR: 使用名字空间别名缩短名字
namespace ATT = American_Telephone_and_Telegraph;