Getting Started
======================================================

.. include:: ./src/Readme_top.md
   :parser: myst_parser.sphinx_

Usage
------

.. include:: ./src/project_options_example.md
   :parser: myst_parser.sphinx_

.. include:: ./src/License.md
   :parser: myst_parser.sphinx_

Table of Contents
==================

.. toctree::
    :maxdepth: 2

    self
    src/index

.. Indices
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`
