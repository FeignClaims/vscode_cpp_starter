## License

This project can be used under the terms of either the [MIT license](../../LICENSE.txt) or the [Unlicense](../../Unlicense.txt) depending on your choice.
