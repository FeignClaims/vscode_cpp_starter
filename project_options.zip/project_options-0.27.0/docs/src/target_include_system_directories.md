# `target_include_system_directories`

Include a system directory (which suppresses its warnings).

The function accepts the same arguments as `target_include_directories`. It has the mentioned features of `target_link_system_libraries`.
