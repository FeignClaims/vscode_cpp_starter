.. include:: ./project_options_example.md
   :parser: myst_parser.sphinx_

.. include:: ./project_options_api.md
   :parser: myst_parser.sphinx_
