#include <mylib/lib.hpp>
#include <mylib2/lib.hpp>

int main() {
    some_fun2();
    return some_fun2();
}