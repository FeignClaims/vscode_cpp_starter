#include <fmt/core.h>

int main() {
  fmt::print("Hello World!");
  return 0;
}